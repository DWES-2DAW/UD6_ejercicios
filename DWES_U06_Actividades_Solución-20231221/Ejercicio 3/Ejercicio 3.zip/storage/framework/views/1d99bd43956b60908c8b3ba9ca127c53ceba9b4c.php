<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        
    </head>
    <body>
        <h1 class="display-1 text-center"><?php echo e(Str::upper($subject->id)); ?> - <?php echo e($subject->name); ?></h1>
          <ul class="list-group">
            <li class="list-group-item">Alias: <?php echo e(Str::upper($subject->id)); ?></li>
            <li class="list-group-item">Nombre: <?php echo e($subject->name); ?></li>
            <li class="list-group-item">Nº Horas: <?php echo e($subject->hours); ?></li>
            <li class="list-group-item">Se cursa en <?php echo e($subject->grade); ?> año</li>
            <li class="list-group-item">Ciclo: <?php echo e(Str::upper($subject->course_id)); ?></li>
          </ul> 
          <h3 class="display-3 text-center">Alumnos que cursan o han cursado la asignatura.</h1>
          <table class="table">
            <tr>
                <th>DNI</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Año</th>
            </tr>
            <?php $__currentLoopData = $subject->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($student->dni); ?></td>
                <td><?php echo e($student->name); ?></td>
                <td><?php echo e($student->last_name); ?></td>
                <td><?php echo e($student->email); ?></td>
                <td><?php echo e($student->phone); ?></td>
                <td><?php echo e($student->pivot->year); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </table>
    
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    </body>
</html>
<?php /**PATH C:\Users\ggarrido\Desktop\college_ggarrido\resources\views/subjects/show.blade.php ENDPATH**/ ?>